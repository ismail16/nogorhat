@include('frontend/partials/header')

        @yield('content')
        <!--home two block section end-->
		<!--static area start-->
{{--		<div class="static_area">--}}
{{--		    <div class="container">--}}
{{--		        <div class="row">--}}
{{--		            <div class="col-lg-4 col-md-6">--}}
{{--		                <div class="single_static mb-30">--}}
{{--		                    <div class="icone_static">--}}
{{--		                        <i class="fa fa-coffee"></i>--}}
{{--		                    </div>--}}
{{--		                    <div class="content_static">--}}
{{--		                        <h4>Free Delivery</h4>--}}
{{--		                        <p>All the beautiful pieces are made in Italy and manufactured with the greatest attention. Now Fashion extends to a range of accessories</p>--}}
{{--		                    </div>--}}
{{--		                </div>--}}
{{--		            </div>--}}
{{--		            <div class="col-lg-4 col-md-6">--}}
{{--		                <div class="single_static mb-30">--}}
{{--		                    <div class="icone_static">--}}
{{--		                        <i class="fa fa-cubes"></i>--}}
{{--		                    </div>--}}
{{--		                    <div class="content_static">--}}
{{--		                        <h4>Big Saving</h4>--}}
{{--		                        <p>All the beautiful pieces are made in Italy and manufactured with the greatest attention. Now Fashion extends to a range of accessories</p>--}}
{{--		                    </div>--}}
{{--		                </div>--}}
{{--		            </div>--}}
{{--		            <div class="col-lg-4 col-md-6">--}}
{{--		                <div class="single_static mb-30">--}}
{{--		                    <div class="icone_static">--}}
{{--		                        <i class="fa fa-tags"></i>--}}
{{--		                    </div>--}}
{{--		                    <div class="content_static">--}}
{{--		                        <h4>Gift Vouchers</h4>--}}
{{--		                        <p>All the beautiful pieces are made in Italy and manufactured with the greatest attention. Now Fashion extends to a range of accessories</p>--}}
{{--		                    </div>--}}
{{--		                </div>--}}
{{--		            </div>--}}
{{--		            <div class="col-lg-4 col-md-6">--}}
{{--		                <div class="single_static">--}}
{{--		                    <div class="icone_static">--}}
{{--		                        <i class="fa fa-codepen"></i>--}}
{{--		                    </div>--}}
{{--		                    <div class="content_static">--}}
{{--		                        <h4>Easy return</h4>--}}
{{--		                        <p>All the beautiful pieces are made in Italy and manufactured with the greatest attention. Now Fashion extends to a range of accessories</p>--}}
{{--		                    </div>--}}
{{--		                </div>--}}
{{--		            </div>--}}
{{--		            <div class="col-lg-4 col-md-6">--}}
{{--		                <div class="single_static">--}}
{{--		                    <div class="icone_static">--}}
{{--		                        <i class="fa fa-cut"></i>--}}
{{--		                    </div>--}}
{{--		                    <div class="content_static">--}}
{{--		                        <h4>Save 20% When You</h4>--}}
{{--		                        <p>All the beautiful pieces are made in Italy and manufactured with the greatest attention. Now Fashion extends to a range of accessories</p>--}}
{{--		                    </div>--}}
{{--		                </div>--}}
{{--		            </div>--}}
{{--		            <div class="col-lg-4 col-md-6">--}}
{{--		                <div class="single_static">--}}
{{--		                    <div class="icone_static">--}}
{{--		                        <i class="fa fa-diamond"></i>--}}
{{--		                    </div>--}}
{{--		                    <div class="content_static">--}}
{{--		                        <h4>Free Delivery Worldwide</h4>--}}
{{--		                        <p>All the beautiful pieces are made in Italy and manufactured with the greatest attention. Now Fashion extends to a range of accessories</p>--}}
{{--		                    </div>--}}
{{--		                </div>--}}
{{--		            </div>--}}
{{--		        </div>--}}
{{--		    </div>--}}
{{--		</div>--}}
		<!--static area end-->

@include('frontend/partials/footer')


